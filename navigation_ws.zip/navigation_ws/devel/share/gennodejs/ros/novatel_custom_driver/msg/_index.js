
"use strict";

let novatel = require('./novatel.js');

module.exports = {
  novatel: novatel,
};
