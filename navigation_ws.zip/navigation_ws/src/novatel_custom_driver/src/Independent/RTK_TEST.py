#!/usr/bin/env python

#import rospy
import serial
import socket
from socket import error as socket_error

###RTK Connection Initialization

TCP_IP = '192.168.0.60'
TCP_PORT = 5017
BUFFER_SIZE = 1024

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((TCP_IP, TCP_PORT))

# Use USB2 for bestpos
ser2 = serial.Serial()
ser2.baudrate = 115200
ser2.port = '/dev/ttyUSB3'
ser2.open()

#Use USB1 for IMU
ser1 = serial.Serial()
ser1.baudrate = 115200
ser1.port = '/dev/ttyUSB4'
ser1.open()

#Use USB0 for velocity
ser0 = serial.Serial()
ser0.baudrate = 115200
ser0.port = '/dev/ttyUSB5'
ser0.open()

## Unlog all previous log calls
ser1.write('unlogall\r\n')
ser2.write('unlogall\r\n')
ser0.write('unlogall\r\n')


#bestpos on USB2
ser2.write('log bestposa ontime 0.05\r\n')

#IMU on USB1
ser1.write('SETIMUTOANTOFFSET 0.54 0.32 1.20 0.03 0.03 0.05\r\n')
ser1.write('log insatta ontime 0.1 \r\n')


#Velocity on USB0
#ser0.write('SETIMUTOANTOFFSET 0.54 0.32 1.20 0.03 0.03 0.05\r\n')
#ser0.write('log insvel ontime 0.05 \r\n')


#SETTING UP RTK
ser0.write('INTERFACEMODE USB1 RTCM NOVATEL ON\r\n')
ser1.write('INTERFACEMODE USB2 RTCM NOVATEL ON\r\n')
ser2.write('INTERFACEMODE USB2 RTCM NOVATEL ON\r\n')

print(ser1.name)
print(ser2.name)

longitude = []
latitude = []
Z = 0


while True:
    #Recieve RTCM and write RTCM data to serial
    RTCM = s.recv(BUFFER_SIZE)
    ser0.write(RTCM)
    ser1.write(RTCM)
    ser2.write(RTCM)

    z = ser2.readline()
    z = z.split(',')

    print(z)
    if len(z) > 1 :
        latitude = float(z[11])
        longitude = float(z[12])
        latitude_dev = float(z[16])
        longitude_dev = float(z[17])
        soln_type = z[10]
        #print(latitude)
        #print ('lat', [latitude, latitude_dev])
        #print('long', [longitude, longitude_dev])
        #print(soln_type)




