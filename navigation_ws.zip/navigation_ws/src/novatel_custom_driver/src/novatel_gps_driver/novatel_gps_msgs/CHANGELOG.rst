^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package novatel_gps_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

3.4.0 (2017-10-06)
------------------
* Add service to novatel_gps_nodelet that issues a FRESET command on the indicated target, or STANDARD if none is provided
* Contributors: Matthew Bries, P. J. Reed

3.3.0 (2017-08-31)
------------------
* Publish sensor_msgs/Imu messages
* Code cleanup
* Contributors: Edward Venator, P. J. Reed

3.2.0 (2017-07-21)
------------------
* Publish IMU data from NovAtel SPAN devices
* Contributors: P. J. Reed

3.1.0 (2017-06-27)
------------------

3.0.1 (2017-05-08)
------------------

3.0.0 (2017-04-03)
------------------
* Rename novatel_msgs to novatel_gps_msgs
* Contributors: P. J. Reed

2.9.0 (2017-01-11)
------------------

2.8.0 (2017-01-05)
------------------

2.7.2 (2016-11-28)
------------------

2.7.0 (2015-09-24 15:37:00 -0500)
---------------------------------
