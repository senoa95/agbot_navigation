#!/usr/bin/env python

import socket


TCP_IP = '192.168.0.60'
TCP_PORT = 5017
BUFFER_SIZE = 1024
i = 0

while True:
	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.connect((TCP_IP, TCP_PORT))
	RTCM = s.recv(BUFFER_SIZE)
	print "received data:", RTCM

