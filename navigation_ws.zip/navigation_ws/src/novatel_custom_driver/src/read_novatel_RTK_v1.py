#!/usr/bin/env python

import rospy
import serial
import math
from socket import error as socket_error
from novatel_custom_driver.msg import novatel


###RTK Connection Initialization

TCP_IP = '192.168.0.60'
TCP_PORT = 5017
BUFFER_SIZE = 1024

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((TCP_IP, TCP_PORT))


#Use USB2 for bestpos
ser2 = serial.Serial()
ser2.baudrate = 115200
ser2.port = '/dev/ttyUSB2'
ser2.open()

#Use USB1 for IMU
ser1 = serial.Serial()
ser1.baudrate = 115200
ser1.port = '/dev/ttyUSB1'
ser1.open()

#Use USB0 for velocity
ser0 = serial.Serial()
ser0.baudrate = 115200
ser0.port = '/dev/ttyUSB0'
ser0.open()


print(ser0.name)
print(ser1.name)
print(ser2.name)
count = 0
longitude = []
latitude = []
x = 0
y = 0
z = 0

ser2.write('unlogall\r\n')
ser1.write('unlogall\r\n')
ser0.write('unlogall\r\n')


ser2.write('log usb3 bestposa ontime 0.05\r\n')



ser1.write('SETIMUTOANTOFFSET 0.54 0.32 1.20 0.03 0.03 0.05\r\n')
ser1.write('log usb2 insatta ontime 0.1 \r\n')


#ser0.write('SETIMUTOANTOFFSET 0.54 0.32 1.20 0.03 0.03 0.05\r\n')
#ser0.write('log usb1 insvel ontime 0.05 \r\n')


#SETTING UP RTK
ser0.write('INTERFACEMODE USB1 RTCM NOVATEL ON\r\n')
ser1.write('INTERFACEMODE USB2 RTCM NOVATEL ON\r\n')
ser2.write('INTERFACEMODE USB2 RTCM NOVATEL ON\r\n')


pub = rospy.Publisher('/novatel_reader', novatel, queue_size=10)
rospy.init_node('GPS', anonymous=True)

rate = rospy.Rate(10) #10 Hz 

current_msg = novatel()

print(ser1.name)
print(ser2.name)

longitude = []
latitude = []
Z = 0


while not rospy.is_shutdown():

#Recieve RTCM and write RTCM data to all USB ports
    RTCM = s.recv(BUFFER_SIZE)
    ser0.write(RTCM)
    ser1.write(RTCM)  
    ser2.write(RTCM)

    #x = ser0.readline()		#for velocity readings
    #x = x.split('\r\n')		#for velocity readings

    y = ser1.readline()
    y = y.split(',')

    z = ser2.readline()
    z = z.split(',')

    if len(z)>10 and len(y) > 10:
      	latitude = float(z[11])
       	longitude = float(z[12])
       	latitude_dev = float(z[16])
	longitude_dev = float(z[17])
	azimuth = float(y[13])

	current_msg.latitude = latitude
	current_msg.longitude = longitude
	current_msg.heading = azimuth

	pub.publish(current_msg)
    rate.sleep()



        #velocity_hor = (x[17])
        #velocity_north = float(x[17])
        #velocity_east = float(x[18])
        #velocity_mag = math.sqrt((float(velocity_north)**2 + float(velocity_east)**2))
        #velocity_dir = math.tan(float(velocity_north)/float(velocity_east))
        #lat_long_azm = [float(latitude),float(longitude), float(azimuth)]
        #lat_long_deviation = [float(latitude_dev), float(longitude_dev)]
        #print(lat_long_azm)
        #print(latitude)
        #print(longitude)
        #print(azimuth)
        #print(velocity_heast)
        #print(velocity_north)
        #print(velocity_mag)
        #print(x)
        #print(y)
        #print(z)
        #print(x)
